/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.contacttreemanager;

/**
 *
 * @author bmpth
 */


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Handles loading and saving contacts from a CSV file.
 */
public class ContactFileManager {

    public static void loadContacts(String filename, ContactBST tree) {
        try {
            File file = new File(filename);

            if (!file.exists()) {
                System.out.println("No saved contacts found. Starting fresh.");
                return;
            }

            Scanner fileScanner = new Scanner(file);

            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();

                if (line.trim().isEmpty()) {
                    continue;
                }

                String[] parts = line.split(",");

                if (parts.length == 6) {
                    String name = parts[0].trim();
                    String phone = parts[1].trim();
                    String email = parts[2].trim();
                    String address = parts[3].trim();
                    String category = parts[4].trim();
                    boolean favorite = Boolean.parseBoolean(parts[5].trim());

                    tree.insert(new Contact(name, phone, email, address, category, favorite));
                }
            }

            fileScanner.close();

        } catch (IOException e) {
            System.out.println("Error loading contacts.");
        }
    }

    public static void saveContacts(String filename, ContactBST tree) {
        try {
            FileWriter writer = new FileWriter(filename);
            ArrayList<Contact> contacts = tree.toList();

            for (Contact contact : contacts) {
                writer.write(contact.toCSV() + "\n");
            }

            writer.close();
            System.out.println("Contacts saved to " + filename);

        } catch (IOException e) {
            System.out.println("Error saving contacts.");
        }
    }
}