/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.contacttreemanager;

/**
 *
 * @author bmpth
 */

import java.util.Scanner;

/**
 * Main application class for the ContactTree Manager.
 */
public class ContactTreeManager {
    private static final String FILE_NAME = "contacts.csv";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ContactBST tree = new ContactBST();

        ContactFileManager.loadContacts(FILE_NAME, tree);

        int choice = 0;

        while (choice != 12) {
            displayMenu();

            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine();
            } else {
                System.out.println("Invalid input. Enter a number.");
                scanner.nextLine();
                continue;
            }

            switch (choice) {
                case 1:
                    addContact(scanner, tree);
                    break;

                case 2:
                    searchContact(scanner, tree);
                    break;

                case 3:
                    updateContact(scanner, tree);
                    break;

                case 4:
                    deleteContact(scanner, tree);
                    break;

                case 5:
                    System.out.println("\nContacts A-Z:");
                    tree.displayAscending();
                    break;

                case 6:
                    System.out.println("\nContacts Z-A:");
                    tree.displayDescending();
                    break;

                case 7:
                    System.out.println("Total contacts: " + tree.countContacts());
                    break;

                case 8:
                    System.out.println("Tree height: " + tree.height());
                    System.out.println("Leaf count: " + tree.countLeaves());
                    System.out.println("Balanced: " + tree.isBalanced());
                    break;

                case 9:
                    System.out.println("First alphabetically: " + tree.findMin());
                    System.out.println("Last alphabetically: " + tree.findMax());
                    break;

                case 10:
                    ContactFileManager.saveContacts(FILE_NAME, tree);
                    break;

                case 11:
                    seedContacts(tree);
                    break;

                case 12:
                    ContactFileManager.saveContacts(FILE_NAME, tree);
                    System.out.println("Exiting ContactTree Manager.");
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }

        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("\n========= ContactTree Manager =========");
        System.out.println("1. Add Contact");
        System.out.println("2. Search Contact");
        System.out.println("3. Update Contact");
        System.out.println("4. Delete Contact");
        System.out.println("5. Display Contacts A-Z");
        System.out.println("6. Display Contacts Z-A");
        System.out.println("7. Count Contacts");
        System.out.println("8. Tree Statistics");
        System.out.println("9. Find First and Last Contact");
        System.out.println("10. Save Contacts");
        System.out.println("11. Load Sample Contacts");
        System.out.println("12. Save and Exit");
        System.out.print("Choose an option: ");
    }

    private static void addContact(Scanner scanner, ContactBST tree) {
        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Phone: ");
        String phone = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        System.out.print("Address: ");
        String address = scanner.nextLine();

        System.out.print("Category: ");
        String category = scanner.nextLine();

        System.out.print("Favorite? true/false: ");
        boolean favorite = Boolean.parseBoolean(scanner.nextLine());

        tree.insert(new Contact(name, phone, email, address, category, favorite));
        System.out.println("Contact added.");
    }

    private static void searchContact(Scanner scanner, ContactBST tree) {
        System.out.print("Enter full name to search: ");
        String name = scanner.nextLine();

        Contact contact = tree.search(name);

        if (contact == null) {
            System.out.println("Contact not found.");
        } else {
            System.out.println("Contact found:");
            System.out.println(contact);
        }
    }

    private static void updateContact(Scanner scanner, ContactBST tree) {
        System.out.print("Enter full name to update: ");
        String name = scanner.nextLine();

        if (tree.search(name) == null) {
            System.out.println("Contact not found.");
            return;
        }

        System.out.print("New phone: ");
        String phone = scanner.nextLine();

        System.out.print("New email: ");
        String email = scanner.nextLine();

        System.out.print("New address: ");
        String address = scanner.nextLine();

        System.out.print("New category: ");
        String category = scanner.nextLine();

        System.out.print("Favorite? true/false: ");
        boolean favorite = Boolean.parseBoolean(scanner.nextLine());

        tree.update(name, phone, email, address, category, favorite);
    }

    private static void deleteContact(Scanner scanner, ContactBST tree) {
        System.out.print("Enter full name to delete: ");
        String name = scanner.nextLine();

        if (tree.search(name) == null) {
            System.out.println("Contact not found.");
            return;
        }

        tree.delete(name);
        System.out.println("Contact deleted.");
    }

    private static void seedContacts(ContactBST tree) {
        tree.insert(new Contact("Brian Pugh", "555-1111", "brian@example.com", "123 Aggie Rd", "School", true));
        tree.insert(new Contact("Aaliyah Phillips", "555-4444", "aaliyah@example.com", "1007 Mountain Dr", "Friend", false));
        tree.insert(new Contact("Rayah Smith", "555-2222", "rayah@example.com", "10880 Malibu Point", "Work", false));
        tree.insert(new Contact("Zimmie Wellington", "555-3333", "zimmie@example.com", "20 Ingram St", "Family", true));
        tree.insert(new Contact("Ayo Blake", "555-5555", "ayo@example.com", "344 Clinton St", "Other", false));

        System.out.println("Sample contacts loaded.");
    }
}