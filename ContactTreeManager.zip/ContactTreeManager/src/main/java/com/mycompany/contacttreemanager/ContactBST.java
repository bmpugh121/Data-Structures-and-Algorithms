/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.contacttreemanager;

/**
 *
 * @author bmpth
 */

import java.util.ArrayList;

/**
 * Binary Search Tree for storing contacts alphabetically by name.
 */
public class ContactBST {
    private TreeNode root;

    public void insert(Contact contact) {
        root = insertRecursive(root, contact);
    }

    private TreeNode insertRecursive(TreeNode current, Contact contact) {
        if (current == null) {
            return new TreeNode(contact);
        }

        int comparison = contact.compareTo(current.contact);

        if (comparison < 0) {
            current.left = insertRecursive(current.left, contact);
        } else if (comparison > 0) {
            current.right = insertRecursive(current.right, contact);
        } else {
            System.out.println("Contact already exists: " + contact.getName());
        }

        return current;
    }

    public Contact search(String name) {
        return searchRecursive(root, name);
    }

    private Contact searchRecursive(TreeNode current, String name) {
        if (current == null) {
            return null;
        }

        int comparison = name.compareToIgnoreCase(current.contact.getName());

        if (comparison == 0) {
            return current.contact;
        } else if (comparison < 0) {
            return searchRecursive(current.left, name);
        } else {
            return searchRecursive(current.right, name);
        }
    }

    public void delete(String name) {
        root = deleteRecursive(root, name);
    }

    private TreeNode deleteRecursive(TreeNode current, String name) {
        if (current == null) {
            return null;
        }

        int comparison = name.compareToIgnoreCase(current.contact.getName());

        if (comparison < 0) {
            current.left = deleteRecursive(current.left, name);
        } else if (comparison > 0) {
            current.right = deleteRecursive(current.right, name);
        } else {
            if (current.left == null && current.right == null) {
                return null;
            }

            if (current.left == null) {
                return current.right;
            }

            if (current.right == null) {
                return current.left;
            }

            Contact smallestContact = findMinNode(current.right).contact;
            current.contact = smallestContact;
            current.right = deleteRecursive(current.right, smallestContact.getName());
        }

        return current;
    }

    private TreeNode findMinNode(TreeNode current) {
        while (current.left != null) {
            current = current.left;
        }

        return current;
    }

    public void update(String name, String phone, String email, String address, String category, boolean favorite) {
        Contact contact = search(name);

        if (contact == null) {
            System.out.println("Contact not found.");
            return;
        }

        contact.setPhone(phone);
        contact.setEmail(email);
        contact.setAddress(address);
        contact.setCategory(category);
        contact.setFavorite(favorite);

        System.out.println("Contact updated.");
    }

    public void displayAscending() {
        inorder(root);
    }

    private void inorder(TreeNode current) {
        if (current != null) {
            inorder(current.left);
            System.out.println(current.contact);
            inorder(current.right);
        }
    }

    public void displayDescending() {
        reverseInorder(root);
    }

    private void reverseInorder(TreeNode current) {
        if (current != null) {
            reverseInorder(current.right);
            System.out.println(current.contact);
            reverseInorder(current.left);
        }
    }

    public int countContacts() {
        return countRecursive(root);
    }

    private int countRecursive(TreeNode current) {
        if (current == null) {
            return 0;
        }

        return 1 + countRecursive(current.left) + countRecursive(current.right);
    }

    public int height() {
        return heightRecursive(root);
    }

    private int heightRecursive(TreeNode current) {
        if (current == null) {
            return -1;
        }

        int leftHeight = heightRecursive(current.left);
        int rightHeight = heightRecursive(current.right);

        return 1 + Math.max(leftHeight, rightHeight);
    }

    public int countLeaves() {
        return countLeavesRecursive(root);
    }

    private int countLeavesRecursive(TreeNode current) {
        if (current == null) {
            return 0;
        }

        if (current.left == null && current.right == null) {
            return 1;
        }

        return countLeavesRecursive(current.left) + countLeavesRecursive(current.right);
    }

    public boolean isBalanced() {
        return checkBalance(root) != -1;
    }

    private int checkBalance(TreeNode current) {
        if (current == null) {
            return 0;
        }

        int left = checkBalance(current.left);
        int right = checkBalance(current.right);

        if (left == -1 || right == -1) {
            return -1;
        }

        if (Math.abs(left - right) > 1) {
            return -1;
        }

        return 1 + Math.max(left, right);
    }

    public Contact findMin() {
        if (root == null) {
            return null;
        }

        return findMinNode(root).contact;
    }

    public Contact findMax() {
        TreeNode current = root;

        if (current == null) {
            return null;
        }

        while (current.right != null) {
            current = current.right;
        }

        return current.contact;
    }

    public ArrayList<Contact> toList() {
        ArrayList<Contact> contacts = new ArrayList<>();
        fillList(root, contacts);
        return contacts;
    }

    private void fillList(TreeNode current, ArrayList<Contact> contacts) {
        if (current != null) {
            fillList(current.left, contacts);
            contacts.add(current.contact);
            fillList(current.right, contacts);
        }
    }
}