/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.contacttreemanager;

/**
 *
 * @author bmpth
 */

/**
 * Represents a contact stored in the Binary Search Tree.
 */
public class Contact implements Comparable<Contact> {
    private String name;
    private String phone;
    private String email;
    private String address;
    private String category;
    private boolean favorite;

    public Contact(String name, String phone, String email, String address, String category, boolean favorite) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.category = category;
        this.favorite = favorite;
    }

    public String getName() {
        return name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

    @Override
    public int compareTo(Contact other) {
        return this.name.compareToIgnoreCase(other.name);
    }

    public String toCSV() {
        return name + "," + phone + "," + email + "," + address + "," + category + "," + favorite;
    }

    @Override
    public String toString() {
        return "Name: " + name
                + " | Phone: " + phone
                + " | Email: " + email
                + " | Address: " + address
                + " | Category: " + category
                + " | Favorite: " + favorite;
    }
}