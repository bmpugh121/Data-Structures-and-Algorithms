/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.contacttreemanager;

/**
 *
 * @author bmpth
 */

/**
 * Node used inside the Binary Search Tree.
 */
public class TreeNode {
    Contact contact;
    TreeNode left;
    TreeNode right;

    public TreeNode(Contact contact) {
        this.contact = contact;
        this.left = null;
        this.right = null;
    }
}